﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu (menuName = "PreloadedData", fileName = "PreloadedData")]
public class PreloadedData : ScriptableObject {

	 // Avatar
    public List<Sprite> avatarItem0;
    public List<Sprite> avatarItem1;
    public List<Sprite> avatarItem2;
    public List<Sprite> avatarItem3;
    public List<Sprite> avatarItem0b;
    public List<Sprite> avatarItem1b;
    public List<Sprite> avatarItem2b;
    public List<Sprite> avatarItem3b;
    public List<Sprite> avatarHairFem;
    public List<Sprite> avatarHairMasc;
    public List<Sprite> avatarBase;
    public Sprite avatarBlank;
	public Sprite noAvatar;
    public int zeroTierMaxIndex;
    public int firstTierMaxIndex;
    public int secondTierMaxIndex;
    public int thirdTierMaxIndex;

    // Sound
	public AudioSource songAudio;
	public AudioSource buttonAudio;
	public AudioClip song1;
	public AudioClip song2;
	public AudioClip positive;
	public AudioClip negative;
	public AudioClip neutral;
	public AudioClip subtle;
	public AudioClip popUp;
	public AudioClip popUpOut;
	public AudioClip blop;
	public AudioClip success;
	public AudioClip error;
	public AudioClip currentSong;
	public AudioClip swipe;
	public AudioClip photography;
	public AudioClip scoreCounter;
		
//		DESAFIO QUIZ, version alpha 0.5 (web only)
//		developed by ROCKET PRO GAMES, rocketprogames@gmail.com
//		script by Eduardo Siqueira
//		São Paulo, Brasil, 2019
}