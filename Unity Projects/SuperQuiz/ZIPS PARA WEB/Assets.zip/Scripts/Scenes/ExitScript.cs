﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ExitScript : MonoBehaviour{

	bool fadeOutSound;
	
	[SerializeField] bool returnToLogin;
	
	void Start(){
		if(SessionScript.soundOn){
			SessionScript.fadeOutSong = true;
		}
		if (returnToLogin){
			Invoke ("ReturnToLogin", 5f);
			GameObject.Find("Canvas/Scroll View/Viewport/Exit/Message").gameObject.SetActive(true);
			return;
		}
		if (Application.platform == RuntimePlatform.Android){
			Invoke ("KillApplication", 0.5f);
		} else{
			GameObject.Find("Canvas/Scroll View/Viewport/Exit/Message").gameObject.SetActive(true);
			Invoke ("QuitApplication", 1f);
		}
	}
	
	
	void KillApplication(){
		System.Diagnostics.Process.GetCurrentProcess().Kill();
	}
	
	void QuitApplication(){
		Application.Quit();
	}
	
	void ReturnToLogin(){
		SceneManager.LoadScene("login", LoadSceneMode.Single);
	}
		
//		DESAFIO QUIZ, version alpha 0.5 (web only)
//		developed by ROCKET PRO GAMES, rocketprogames@gmail.com
//		script by Eduardo Siqueira
//		São Paulo, Brasil, 2019
}

