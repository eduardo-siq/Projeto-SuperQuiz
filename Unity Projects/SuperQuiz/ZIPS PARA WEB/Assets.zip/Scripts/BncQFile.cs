﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
[System.Serializable]
class BncQFile {
	public List<string> t;
	public List<int> tp;
	public List<string> a;
	public List<string> b;
	public List<string> c;
	public List<string> d;
	public List<string> e;
	public List<string> u;
	public List<string> s;
	public string client;
	public List<string> uName;
	public List<string> sName;
		
//		DESAFIO QUIZ, version alpha 0.5 (web only)
//		developed by ROCKET PRO GAMES, rocketprogames@gmail.com
//		script by Eduardo Siqueira
//		São Paulo, Brasil, 2019
}